#include "bit_operations.h"
#include <string.h>
#include <stdio.h>
#include <math.h>

int bit_to_one(int num, int mask){
	num |= mask;
	return num;
}

int bit_to_zero(int num, int mask){
	num &= bit_inversion(mask, 0xFFFFFFFF);
	return num;
}

int bit_inversion(int num, int mask){
	num ^= mask;
	return num;
}

int logical_move_r(int num, unsigned int count){
	num >>= count;
	return num;
}

int logical_move_l(int num, unsigned int count){
	num <<= count;
	return num;
}

int cyclic_move_r(int num, unsigned int count){
	num = (num >> count) | (num << ((sizeof(int) * 8) - count));
	return num;
}

int cyclic_move_l(int num, unsigned int count){
	num = (num << count) | (num >> ((sizeof(int) * 8) - count));
	return num;
}
