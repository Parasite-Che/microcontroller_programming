#include "bit_operations.h"
#include <math.h>
#include <stdio.h>


int main() {
  int num = 102;
	int mask = 60;
	unsigned int count = 3;
	int bto = bit_to_one(num, mask);
	int btz = bit_to_zero(num, mask);
	int bi = bit_inversion(num, mask);
	int lmr = logical_move_r(num, count);
	int lml = logical_move_l(num, count);
	int cmr = cyclic_move_r(num, count);
	int cml = cyclic_move_l(num, count);
	
	return 0;
}
